export default [
    {
        id: 1,
        title: 'JavaScript is the best language there is',
        content: 'Some content here 1',
        author: 'Pesho'
    },
    {
        id: 2,
        title: 'Second Article',
        content: 'Some content here 2'
    },
    {
        id: 3,
        title: 'Third Article',
        content: 'Some content here 3'
    },
    {
        id: 4,
        title: 'Fourth Article',
        content: 'Some content here 4'
    },
];