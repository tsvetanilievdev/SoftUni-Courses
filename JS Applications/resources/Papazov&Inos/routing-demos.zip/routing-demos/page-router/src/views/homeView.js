export default function(context) {
    console.log('Home loaded');
    console.log(context);
}