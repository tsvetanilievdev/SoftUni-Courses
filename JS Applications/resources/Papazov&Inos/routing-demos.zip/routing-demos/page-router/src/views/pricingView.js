export default function(context) {
    console.log('Pricing loaded');
    console.log(context);
}