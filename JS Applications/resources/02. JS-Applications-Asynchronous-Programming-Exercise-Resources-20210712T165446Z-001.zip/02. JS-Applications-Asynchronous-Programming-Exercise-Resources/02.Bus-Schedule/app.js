function solve() {
    let baseUrl = 'http://localhost:3030/jsonstore/bus/schedule/'


    //select buttons
    let btnDepart = document.getElementById('depart');
    let btnArrive = document.getElementById('arrive');

    let id = 'depot'

    function depart() {
        fetch(`${baseUrl}${id}`)

        btnDepart.disabled = true;
        btnArrive.disabled = false;
    }

    function arrive() {
        btnDepart.disabled = false;
        btnArrive.disabled = true;
    }

    return {
        depart,
        arrive
    };
}

let result = solve();